

class Upgrade {
  constructor(id, upgradeLevel = 0) {
    this.id = id;
    this.upgradeLevel = upgradeLevel;
    this.isSinglePurchase = false;
  }

  buyAction() {
  }

  updateUiText() {
  }
  
  updateUiDisabled() {
  }

  calcluateCost() {
  }
}
